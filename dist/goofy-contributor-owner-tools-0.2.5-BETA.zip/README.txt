OWNER ONLY - CONTRIBUTOR ENROLLMENT TOOLS

Copy tools/gameplay-collector/enroll.mjs into your existing collector folder.
Keep your existing wrangler.jsonc, D1 binding, private enrollment registry and keys.
If updating an older checkout, copy tools/bazaar-calc/data-paths.mjs too.
Node 22+ is needed for this owner-side tool. Testers configure keys in Minecraft.

Run in your existing tools/gameplay-collector folder:
  node enroll.mjs import tester-01 "C:\private\tester-01.key"
Or generate a key:
  node enroll.mjs add tester-01

Update the existing Worker's approved hash list:
  npx wrangler@4.147.0 secret put CONTRIBUTOR_HASHES
Paste the FULL contents of the printed contributor-hashes.json file at the prompt.
No public issuance endpoint and no Worker code deployment is required.

To revoke:
  node enroll.mjs revoke tester-01
  npx wrangler@4.147.0 secret put CONTRIBUTOR_HASHES
Paste the UPDATED full hash list. Keep all raw keys and the registry private.
Read docs/SHARED-LEARNING.md for complete instructions.
