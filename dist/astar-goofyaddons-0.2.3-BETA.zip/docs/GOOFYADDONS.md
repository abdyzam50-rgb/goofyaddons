# Trading inside A*

The combined **A* with GoofyAddons 0.2.3-BETA** targets Minecraft **26.3**,
Fabric Loader **0.19.5 or newer**, Fabric API **0.161.0+26.3**, and Java **25**.
It includes the trader from GoofyAddons 1.3.57 in one client JAR.

## Installation and saved data

Replace the standalone A* and GoofyAddons JARs with the combined JAR. Keep Fabric
API for Minecraft 26.3. Installing both the standalone and combined versions
would duplicate their mod IDs/classes and initialization.

Keep `config/goofyaddons.json` and every existing `config/goofyaddons-*.json`
record. Orders, inventory/storage observations, production jobs, profit receipts
and execution history retain their original paths and formats. Keep A*'s saved
maps under `astar/places` too.

If your launcher creates a separate Minecraft 26.3 instance, copy those saved
config records into the new instance's config directory. The mod reads the active
instance; it does not search other instances or guess which account files to adopt.
The calculator's existing external data directory and collector settings remain
compatible. There is no need to reenroll contributors or deploy Cloudflare again.

Old GLFW keyboard bindings are migrated to Minecraft 26.3's SDL scancodes in
memory. Old default J/K/M bindings become F6/F7/F8; customized start and mode keys are retained. The new `keyCodeSchema: 2` marker is written when
settings are saved. Unsupported legacy keys stop config loading instead of
silently changing bindings. The original file stays intact until an explicit save.

## Macros page

Press **G**, then **Macros**. Stop trading with **F6** before opening settings.

The native A* window now includes:

- Trader status, current task, observed purse and confirmed receipt profit.
- Start/stop and Books/General/Both mode.
- Capital limit, purse reserve, and active book/item slot limits.
- Calculator analysis, automatic route selection, and the account dashboard.
- AUTO/COMMAND/NPC Bazaar access and account skill checks.
- Regional daily rests, time zone, and the existing login/logout range fields.
- Explicit save/review and reload controls.

Settings edits validate before an atomic file replacement. A bad value or failed
write preserves the last working settings. Editing requires stopping trading.
Fresh installs still require reviewing the capital and reserve defaults; the
**Save reviewed** control acknowledges them. Start closes the window before
transaction menus open. F6 toggles trading on and off; F7 switches mode and F8 reloads the config.

Advanced limits, recipe selection and production commands remain available in
the existing config and command system. The calculator companion remains separate:

```powershell
node .\tools\bazaar-calc\server.mjs
```

Open the local calculator address printed by that command. Its account dashboard,
inventory/storage views, rankings and learned market estimates continue to work.

## Navigator ownership and NPC access

The trader uses A*'s real navigator for a **loaded Bazaar NPC**. It discovers the
actual NPC/hologram, chooses a nearby standable point with interaction visibility,
and plans a walking route. It does not hardcode another island's coordinates.
Failed approach points are not repeated indefinitely, and the trader retains its
existing navigation timeout.

Menu opening, stop, manual input, world changes and trading pauses release owned
navigation. Trading and a manual A* route/trace playback cannot own movement at
the same time. The adapter never cancels an unrelated replacement route as though
it owned it. Teleport movement is not enabled for NPC access in this stage.

An NPC outside loaded entities still requires coming into range. Whole-Hub
landmark travel, Kat/Forge/AH physical access, and background wandering remain
separate integration work.

## Production scope and validation

Existing book/general trading, inventory crafting, opt-in BIN listing commands,
saved arrays, scheduled rests and gameplay evidence collection are retained.
Automatic craft/Kat/Forge/AH buy/process/sell route selection remains unfinished;
the integration does not turn the previously research-only routes into executable
ones. See the preserved production and auction guides under
`integrations/goofyaddons/docs`.

The combined build runs the A* core/pathing/movement tests, the trader regression
tests, keyboard migration/config-write tests, and a real Java-to-Node calculator
integration. Compilation and headless checks are verified. A live Minecraft GUI
and Hypixel NPC/transaction session have not been exercised in this cloud environment.

## Build and provenance

```powershell
.\gradlew.bat -p client test calculatorIntegrationTest build
```

The resulting mod is `client/build/libs/astar-client-0.2.3-BETA.jar`. The existing
top-level headless library build remains separate.

GoofyAddons source is retained under `integrations/goofyaddons`; `UPSTREAM.json`
records the imported repository and commit. Its standalone Fabric descriptor is
excluded from the combined resources. A*'s descriptor initializes the trader once,
then A*, and registers the trader's packet mirror mixin. Both license notices are
included in the JAR: A*'s PolyForm Noncommercial license and the trader's MIT notice.

### Keybinds

In **G → Macros → Keybinds**, click **Change** next to an action, then press its new key. Escape cancels. Changes are saved immediately while trading is stopped and also appear in Minecraft Controls. Defaults are F6 for trading on/off, F7 for switching mode, and F8 for reloading. Paused or recovering trading and armed rest schedules count as on: the toggle stops them. Starting requires a connected world with no menu open. Old default J/K/M controls migrate to the new defaults; a customized old start key becomes the toggle.

### Unified commands

Type `.a* goofyaddon` for help. All trader commands now use this local namespace and A*'s Tab completion and Up/Down history:

- `.a* goofyaddon start`, `stop`, `toggle`, or `status`
- `.a* goofyaddon mode books`, `general`, or `both`
- `.a* goofyaddon reload`
- `.a* goofyaddon debug export`
- `.a* goofyaddon profit` (and `hud`, `reset`, `left`, `right`, `scale`)
- `.a* goofyaddon schedule` (and `on`, `off`)
- `.a* goofyaddon craft PRODUCT_ID [BATCHES]`
- `.a* goofyaddon production jobs` or `recipes PRODUCT_ID`
- `.a* goofyaddon auction inspect`, `prepare PRODUCT_ID PRICE`, or `sell PRODUCT_ID PRICE MAXIMUM_FEE`

The old standalone `/goofy...` commands are no longer registered. `.astar goofyaddon ...` is also accepted through A*'s existing prefix alias.

### Unloaded Bazaar icons

During book or ordinary-item transaction navigation, a server menu action appearing as vanilla bedrock is treated as unloaded. The trader waits 1.5 seconds before reopening the product flow, with a maximum of three reopens per operation. It then revalidates the menu, item and transaction normally. Inventory bedrock does not trigger recovery, and a held cursor item prevents closing. Transactions already submitted stay in verification and are never restarted by this recovery.

### Discord and transfer recovery

The optional **Discord companion** card enables paired status updates, contact alerts, and manual remote controls. Follow [DISCORD.md](DISCORD.md) for setup. Discord credentials live in the companion's persistent private data folder. Active server transfers now trigger normal saved-position recovery after the new SkyBlock world stabilizes; no forced Hub/island round trip is used.
