# Public calculator — visitors install nothing

The calculator is a public website, served by the existing
`goofy-gameplay-collector` Cloudflare Worker. After the updated files are deployed,
the intended public address is:

**https://goofy-gameplay-collector.abdyzam50.workers.dev/**

The root opens `/calculator/`. Anyone can open that link from a phone or computer
without Minecraft, a mod, Node, an account, a contributor key or an API key.
Market calculations run in the browser against live public Hypixel Bazaar
prices. The full flip categories and planner are included. A username is optional:
visitors can import a profile's purse and published unlocks, or enter a budget.

The owner's private Hypixel key enables username lookup through the shared API.
It is not sent to visitors. Each visitor's calculator preferences stay in their
own browser. There is no public access to the mod's private inventory, controls
or trading dashboard. The local dashboard remains an optional companion for mod
users, separate from public access.

## Owner publishes once

The updated website is prepared in source and `dist/goofyaddons-public-website.zip`.
It is not published simply by building or downloading this ZIP. The existing
online Worker must be redeployed with these assets. Visitors never run the
commands below.

1. Update the collector source files and `tools/bazaar-calc/calculator/`. Keep the
   existing folder structure. The ZIP contains those files without credentials.
2. Preserve your existing D1 binding and database ID in `wrangler.jsonc`.
   The template's `REPLACE_WITH_CREATED_DATABASE_ID` must not replace your actual
   database ID. Keep both contributor secrets and the GitHub token.
3. Ensure the configuration includes these additional bindings:

```json
"assets": {
  "directory": "../bazaar-calc/calculator",
  "binding": "ASSETS",
  "run_worker_first": true
},
"ratelimits": [{
  "name": "PROFILE_RATE_LIMITER",
  "namespace_id": "1001",
  "simple": { "limit": 5, "period": 60 }
}]
```

4. From the updated `tools/gameplay-collector` directory, run:

```powershell
npx wrangler@4.147.0 secret put HYPIXEL_API_KEY
npx wrangler@4.147.0 deploy
```

Paste the owner's application API key at the secret prompt, never into source or
chat. Obtain the key at https://developer.hypixel.net/. If it was already stored,
only `deploy` is needed. Wrangler uploads the whole website along with the Worker.
Uploading only the browser-editor JavaScript does not upload the website assets.

5. Open the public address in a private/incognito browser window. The calculator
   should open without installing anything. Load a username to verify profile
   lookup, and open a category directly to verify page navigation.

Local verification covers asset routing, private-key handling, upload permissions,
browser calculations and purse budgets. Live Cloudflare publication requires
access to the owner's Cloudflare account, which is unavailable in the coding
environment; there is no claim that this prepared build is already online.
