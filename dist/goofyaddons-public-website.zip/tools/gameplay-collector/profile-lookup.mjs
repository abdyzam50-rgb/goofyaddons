// Read-only account lookup. Hypixel profile fields: PublicAPI v2 SkyBlock profiles;
// progression thresholds: MIT NotEnoughUpdates-REPO constants/leveling.json.
// Nothing returned here is written to the shared gameplay dataset or GitHub.
import { LEVELS } from './profile-levels.mjs';
const profileJson=(status,body)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':'*'}});
const present=n=>typeof n==='number'&&Number.isFinite(n)&&n>=0;
const clean=s=>typeof s==='string'?s.replace(/§./g,'').slice(0,80):'';
function xpLevel(xp,steps,cap=steps.length) {
 if(!present(xp))return null;
 let level=0,left=xp;
 for(const cost of steps.slice(0,cap)){if(left<cost)break;left-=cost;level++;}
 return level;
}
export function summarizeProfiles(data,uuid,resources,now=Date.now()) {
 if(data?.success!==true||!Array.isArray(data.profiles))throw new Error('Profile data unavailable');
 const collections=new Map();
 for(const category of Object.values(resources?.collections??{}))for(const [id,item] of Object.entries(category.items??{}))collections.set(id,clean(item.name));
 return data.profiles.slice(0,10).flatMap(p=>{
  const member=p.members?.[uuid];if(!member)return [];
  const unknown=[],skills={},slayers={},tiers={},reputation={};
  const experience=member.player_data?.experience;
  for(const name of ['enchanting','taming','foraging']) {
   const xp=experience?.[`SKILL_${name.toUpperCase()}`]??member[`experience_skill_${name}`];
   const level=xpLevel(xp,LEVELS.leveling_xp,LEVELS.leveling_caps[name]);
   if(level===null)unknown.push(name);else skills[name[0].toUpperCase()+name.slice(1)]=level;
  }
  const hotm=xpLevel(member.mining_core?.experience,LEVELS.HOTM);
  if(hotm===null)unknown.push('Heart of the Mountain');
  const quick=member.mining_core?.nodes?.forge_time;
  if(!present(quick))unknown.push('Quick Forge');
  const unlocked=member.player_data?.unlocked_coll_tiers??member.unlocked_coll_tiers;
  if(Array.isArray(unlocked)&&collections.size) {
   for(const value of unlocked) {
    const m=typeof value==='string'&&/^(.+)_(\d+)$/.exec(value),name=m&&collections.get(m[1]);
    if(name)tiers[name]=Math.max(tiers[name]??0,Number(m[2]));
   }
  }else unknown.push('collections');
  if(member.slayer_bosses)for(const [id,boss] of Object.entries(member.slayer_bosses)) {
   const table=LEVELS.slayer_xp[id];
   if(table&&present(boss.xp))slayers[({enderman:'Enderman',vampire:'Vampire'})[id]??id[0].toUpperCase()+id.slice(1)]=table.filter(n=>boss.xp>=n).length;
  }else unknown.push('slayers');
  for(const [field,label] of [['barbarians_reputation','Barbarian'],['mages_reputation','Mage']]) {
   const n=member.nether_island_player_data?.[field];if(present(n))reputation[label]=n;
  }
  if(!Object.keys(reputation).length)unknown.push('faction reputation');
  // SkyBlock profiles do not reliably publish the current vanilla XP level.
  unknown.push('current XP levels');
  const purse=member.currencies?.coin_purse??member.coin_purse;
  return [{id:clean(p.profile_id),name:clean(p.cute_name)||'Profile',selected:p.selected===true,gameMode:clean(p.game_mode)||'normal',
   purse:present(purse)&&purse<=1e13?purse:null,fetchedAt:now,unknown,
   stats:{hotmTier:hotm??0,quickForgeLevel:present(quick)?Math.min(20,quick):0,enchantingLevel:skills.Enchanting??0,skills,collections:tiers,slayers,reputation,
    xpLevels:0,ignoreRequirements:false,coleMoltenForge:false,quadTaxes:false,npcShoppingSpree:false}}];
 });
}
export async function lookupProfiles(username,key,fetcher=fetch,now=Date.now()) {
 const get=async(url,headers={})=>{
  const r=await fetcher(url,{headers,signal:AbortSignal.timeout(10000)});
  if(!r.ok)throw new Error(r.status===429?'Lookup temporarily rate limited':r.status===404?'Username not found':'Account service unavailable');
  return r.json();
 };
 const player=await get(`https://api.mojang.com/users/profiles/minecraft/${encodeURIComponent(username)}`);
 if(!/^[a-f0-9]{32}$/i.test(player.id))throw new Error('Username not found');
 const [data,resources]=await Promise.all([
  get(`https://api.hypixel.net/v2/skyblock/profiles?uuid=${player.id}`,{'API-Key':key}),
  get('https://api.hypixel.net/v2/resources/skyblock/collections').catch(()=>null)
 ]);
 return {protocol:'goofy-profile/1',username:clean(player.name),fetchedAt:now,profiles:summarizeProfiles(data,player.id,resources,now)};
}
export async function handleProfileLookup(request,env,now=Date.now(),fetcher=fetch) {
 const username=new URL(request.url).searchParams.get('username')??'';
 if(!/^[A-Za-z0-9_]{1,16}$/.test(username))return profileJson(400,{error:'Enter a Minecraft username (letters, numbers, underscore)'});
 if(!env.HYPIXEL_API_KEY||!env.PROFILE_RATE_LIMITER)return profileJson(503,{error:'Profile lookup is not configured; use a manual budget and unlocks'});
 // Cloudflare supplies this header; a missing limiter fails closed. No public key registration.
 const ip=request.headers.get('CF-Connecting-IP');
 if(!ip)return profileJson(400,{error:'Client address unavailable'});
 const limit=await env.PROFILE_RATE_LIMITER.limit({key:ip});
 if(!limit.success)return profileJson(429,{error:'Too many lookups; try again in a minute'});
 try{
  const cacheKey=username.toLowerCase(),cached=profileCache.get(cacheKey);
  if(cached&&now-cached.at<300000)return profileJson(200,cached.value);
  const value=await lookupProfiles(username,env.HYPIXEL_API_KEY,fetcher,now);
  if(profileCache.size>=256)profileCache.delete(profileCache.keys().next().value);
  profileCache.set(cacheKey,{at:now,value});
  return profileJson(200,value);
 }
 catch(error){return profileJson(502,{error:['Username not found','Lookup temporarily rate limited','Profile data unavailable'].includes(error.message)?error.message:'Account service unavailable'});}
}
// Short-lived isolate memory only: no D1, persistent account history or shared publication.
const profileCache=new Map();
